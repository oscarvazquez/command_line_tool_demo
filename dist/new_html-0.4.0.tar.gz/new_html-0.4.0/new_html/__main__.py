from .new_html import new_html
new_html()