class Stuff(object):
    pass